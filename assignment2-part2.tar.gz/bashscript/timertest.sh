#!/bin/bash
#echo "$(date +'%d/%m/%Y %H:%M:%S:%3N')"

# each for loop iteration is 1 millisecond delay

i=1
j=$1


for as in `seq 1 $i` ; do
  i=1;
done
#echo "$(date +'%d/%m/%Y %H:%M:%S:%3N')"
